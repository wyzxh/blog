// export function getIndex (path) {
//   return path === '/' ? '/index' : path
// }
